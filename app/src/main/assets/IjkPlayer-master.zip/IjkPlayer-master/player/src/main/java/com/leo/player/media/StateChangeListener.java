package com.leo.player.media;

/**
 * Created on 2017/8/16 下午2:33.
 * leo linxiaotao1993@vip.qq.com
 */

public interface StateChangeListener {

    void notifyPlayState(int statue);

}
